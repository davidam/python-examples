
Python Super Stupid Space Invaders (PySSSI)

Updated: January 28, 2007 - Release 1.0

#include <std_disclaimers.h>

It's space invaders. Defend your planet already!!

There is also a "meteor storm" kinda level, playing with rotations.

And there is a Boss level now too. Woot!!

(I'm writing this in order to learn Python... please offer any
criticism and/or observations you'd like regarding this!)

-------------------------------------------------------------------

The History of SSSI

In high school (1984) my friend Greg and I challenged each other to
write space invaders. He was a TRS-80 (Trash 80) guy and I was an
Apple ][+ guy, and we both had at it. The programs were written in
Z-80 and 6502 assembly code and after a few days/weeks of coding
them, comparing and taunting each other to add features, we
eventually gave it up and got on with our lives.

About a decade later I wrote SSSI for the 80x25 IBM PC text-mode
screen, just to revamp it a little bit and have some fun. You can see
that particular version at www.plbm.com/text

Presently I am working on Crazy Invaders as a real PLBM Games product,
but in the meantime I thought I'd teach myself Python with PYSSSI,
or Python Super Stupid Space Invaders, and here it is.

As a historical note, the invader shapes, while clearly patterned
after the original game, are actually the exact original bitmaps
I created in about 1984 when I wrote a TRS-80 Model 100 version of
Space Invaders called SPIN.CO, which you can download and play on
my Virtual Vanessa TRS-80 Model 100 emulator.
