from django.urls import path
#from django.core.urlresolvers import reverse
from . import views

urlpatterns = [
    path('', views.index, name='index'),
]

